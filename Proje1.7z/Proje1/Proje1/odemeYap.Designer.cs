﻿namespace Proje1
{
    partial class odemeYap
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rdNakit = new System.Windows.Forms.RadioButton();
            this.rdKredikart = new System.Windows.Forms.RadioButton();
            this.rdHavaleEft = new System.Windows.Forms.RadioButton();
            this.gbNakit = new System.Windows.Forms.GroupBox();
            this.lblNiTop = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lblNGTop = new System.Windows.Forms.Label();
            this.gbKredikart = new System.Windows.Forms.GroupBox();
            this.comboBox6 = new System.Windows.Forms.ComboBox();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.txtYil = new System.Windows.Forms.ComboBox();
            this.comboBox5 = new System.Windows.Forms.ComboBox();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.txtAy = new System.Windows.Forms.ComboBox();
            this.txtCvv = new System.Windows.Forms.MaskedTextBox();
            this.txtKartno = new System.Windows.Forms.MaskedTextBox();
            this.txtAdsoyad = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.lblKKiTop = new System.Windows.Forms.Label();
            this.lblKKGt = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.gbHavaleEft = new System.Windows.Forms.GroupBox();
            this.lblHEKodu = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblHEiTop = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.lblHEGTop = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.listBox2 = new System.Windows.Forms.ListBox();
            this.listBox3 = new System.Windows.Forms.ListBox();
            this.listBox4 = new System.Windows.Forms.ListBox();
            this.button1 = new System.Windows.Forms.Button();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.gbNakit.SuspendLayout();
            this.gbKredikart.SuspendLayout();
            this.gbHavaleEft.SuspendLayout();
            this.SuspendLayout();
            // 
            // rdNakit
            // 
            this.rdNakit.AutoSize = true;
            this.rdNakit.Checked = true;
            this.rdNakit.Location = new System.Drawing.Point(437, 12);
            this.rdNakit.Name = "rdNakit";
            this.rdNakit.Size = new System.Drawing.Size(58, 19);
            this.rdNakit.TabIndex = 1;
            this.rdNakit.TabStop = true;
            this.rdNakit.Text = "NAKİT";
            this.rdNakit.UseVisualStyleBackColor = true;
            this.rdNakit.CheckedChanged += new System.EventHandler(this.rdNakit_CheckedChanged);
            // 
            // rdKredikart
            // 
            this.rdKredikart.AutoSize = true;
            this.rdKredikart.Location = new System.Drawing.Point(496, 12);
            this.rdKredikart.Name = "rdKredikart";
            this.rdKredikart.Size = new System.Drawing.Size(89, 19);
            this.rdKredikart.TabIndex = 2;
            this.rdKredikart.Text = "KREDİ KARTI";
            this.rdKredikart.UseVisualStyleBackColor = true;
            this.rdKredikart.CheckedChanged += new System.EventHandler(this.rdKredikart_CheckedChanged);
            // 
            // rdHavaleEft
            // 
            this.rdHavaleEft.AutoSize = true;
            this.rdHavaleEft.Location = new System.Drawing.Point(591, 12);
            this.rdHavaleEft.Name = "rdHavaleEft";
            this.rdHavaleEft.Size = new System.Drawing.Size(90, 19);
            this.rdHavaleEft.TabIndex = 3;
            this.rdHavaleEft.Text = "HAVALE/EFT";
            this.rdHavaleEft.UseVisualStyleBackColor = true;
            this.rdHavaleEft.CheckedChanged += new System.EventHandler(this.rdHavaleEft_CheckedChanged);
            // 
            // gbNakit
            // 
            this.gbNakit.Controls.Add(this.lblNiTop);
            this.gbNakit.Controls.Add(this.label5);
            this.gbNakit.Controls.Add(this.label6);
            this.gbNakit.Controls.Add(this.lblNGTop);
            this.gbNakit.Location = new System.Drawing.Point(370, 37);
            this.gbNakit.Name = "gbNakit";
            this.gbNakit.Size = new System.Drawing.Size(318, 127);
            this.gbNakit.TabIndex = 4;
            this.gbNakit.TabStop = false;
            this.gbNakit.Text = "NAKİT ÖDEME";
            // 
            // lblNiTop
            // 
            this.lblNiTop.AutoSize = true;
            this.lblNiTop.Location = new System.Drawing.Point(109, 55);
            this.lblNiTop.Name = "lblNiTop";
            this.lblNiTop.Size = new System.Drawing.Size(38, 15);
            this.lblNiTop.TabIndex = 1;
            this.lblNiTop.Text = "label3";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(17, 28);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(82, 15);
            this.label5.TabIndex = 0;
            this.label5.Text = "Genel Toplam:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(17, 55);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(82, 15);
            this.label6.TabIndex = 0;
            this.label6.Text = "İndirimli Fiyat:";
            // 
            // lblNGTop
            // 
            this.lblNGTop.AutoSize = true;
            this.lblNGTop.Location = new System.Drawing.Point(110, 31);
            this.lblNGTop.Name = "lblNGTop";
            this.lblNGTop.Size = new System.Drawing.Size(38, 15);
            this.lblNGTop.TabIndex = 1;
            this.lblNGTop.Text = "label3";
            // 
            // gbKredikart
            // 
            this.gbKredikart.Controls.Add(this.comboBox6);
            this.gbKredikart.Controls.Add(this.comboBox4);
            this.gbKredikart.Controls.Add(this.txtYil);
            this.gbKredikart.Controls.Add(this.comboBox5);
            this.gbKredikart.Controls.Add(this.comboBox3);
            this.gbKredikart.Controls.Add(this.txtAy);
            this.gbKredikart.Controls.Add(this.txtCvv);
            this.gbKredikart.Controls.Add(this.txtKartno);
            this.gbKredikart.Controls.Add(this.txtAdsoyad);
            this.gbKredikart.Controls.Add(this.label9);
            this.gbKredikart.Controls.Add(this.label8);
            this.gbKredikart.Controls.Add(this.label7);
            this.gbKredikart.Controls.Add(this.label4);
            this.gbKredikart.Controls.Add(this.label13);
            this.gbKredikart.Controls.Add(this.label12);
            this.gbKredikart.Controls.Add(this.lblKKiTop);
            this.gbKredikart.Controls.Add(this.lblKKGt);
            this.gbKredikart.Controls.Add(this.label2);
            this.gbKredikart.Controls.Add(this.label1);
            this.gbKredikart.Location = new System.Drawing.Point(353, 228);
            this.gbKredikart.Name = "gbKredikart";
            this.gbKredikart.Size = new System.Drawing.Size(434, 193);
            this.gbKredikart.TabIndex = 4;
            this.gbKredikart.TabStop = false;
            this.gbKredikart.Text = "KREDİ KARTI İLE ÖDEME";
            // 
            // comboBox6
            // 
            this.comboBox6.FormattingEnabled = true;
            this.comboBox6.Location = new System.Drawing.Point(438, 272);
            this.comboBox6.Name = "comboBox6";
            this.comboBox6.Size = new System.Drawing.Size(59, 23);
            this.comboBox6.TabIndex = 8;
            // 
            // comboBox4
            // 
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Location = new System.Drawing.Point(388, 272);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(59, 23);
            this.comboBox4.TabIndex = 8;
            // 
            // txtYil
            // 
            this.txtYil.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtYil.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.txtYil.FormattingEnabled = true;
            this.txtYil.Items.AddRange(new object[] {
            "2021",
            "2022",
            "2023",
            "2024",
            "2025",
            "2026",
            "2027",
            "2028",
            "2029",
            "2030",
            "2031"});
            this.txtYil.Location = new System.Drawing.Point(349, 137);
            this.txtYil.Name = "txtYil";
            this.txtYil.Size = new System.Drawing.Size(59, 23);
            this.txtYil.TabIndex = 8;
            // 
            // comboBox5
            // 
            this.comboBox5.FormattingEnabled = true;
            this.comboBox5.Location = new System.Drawing.Point(397, 272);
            this.comboBox5.Name = "comboBox5";
            this.comboBox5.Size = new System.Drawing.Size(35, 23);
            this.comboBox5.TabIndex = 7;
            // 
            // comboBox3
            // 
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Location = new System.Drawing.Point(347, 272);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(35, 23);
            this.comboBox3.TabIndex = 7;
            // 
            // txtAy
            // 
            this.txtAy.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtAy.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.txtAy.FormattingEnabled = true;
            this.txtAy.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12"});
            this.txtAy.Location = new System.Drawing.Point(255, 137);
            this.txtAy.Name = "txtAy";
            this.txtAy.Size = new System.Drawing.Size(43, 23);
            this.txtAy.TabIndex = 7;
            // 
            // txtCvv
            // 
            this.txtCvv.Location = new System.Drawing.Point(44, 138);
            this.txtCvv.Mask = "000";
            this.txtCvv.Name = "txtCvv";
            this.txtCvv.Size = new System.Drawing.Size(52, 23);
            this.txtCvv.TabIndex = 6;
            this.txtCvv.ValidatingType = typeof(int);
            // 
            // txtKartno
            // 
            this.txtKartno.BeepOnError = true;
            this.txtKartno.Location = new System.Drawing.Point(62, 74);
            this.txtKartno.Mask = "0000-0000-0000-0000";
            this.txtKartno.Name = "txtKartno";
            this.txtKartno.Size = new System.Drawing.Size(187, 23);
            this.txtKartno.TabIndex = 6;
            // 
            // txtAdsoyad
            // 
            this.txtAdsoyad.Location = new System.Drawing.Point(143, 108);
            this.txtAdsoyad.Name = "txtAdsoyad";
            this.txtAdsoyad.Size = new System.Drawing.Size(266, 23);
            this.txtAdsoyad.TabIndex = 4;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(110, 141);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(114, 15);
            this.label9.TabIndex = 1;
            this.label9.Text = "Son Kullanma Tarihi:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 141);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(32, 15);
            this.label8.TabIndex = 1;
            this.label8.Text = "CVV:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(5, 109);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(135, 15);
            this.label7.TabIndex = 1;
            this.label7.Text = "Kart Sahibi İsim Soyisim:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 82);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(50, 15);
            this.label4.TabIndex = 1;
            this.label4.Text = "Kart No:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(316, 140);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(20, 15);
            this.label13.TabIndex = 1;
            this.label13.Text = "Yıl";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(228, 141);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(21, 15);
            this.label12.TabIndex = 1;
            this.label12.Text = "Ay";
            // 
            // lblKKiTop
            // 
            this.lblKKiTop.AutoSize = true;
            this.lblKKiTop.Location = new System.Drawing.Point(110, 52);
            this.lblKKiTop.Name = "lblKKiTop";
            this.lblKKiTop.Size = new System.Drawing.Size(38, 15);
            this.lblKKiTop.TabIndex = 1;
            this.lblKKiTop.Text = "label3";
            // 
            // lblKKGt
            // 
            this.lblKKGt.AutoSize = true;
            this.lblKKGt.Location = new System.Drawing.Point(110, 28);
            this.lblKKGt.Name = "lblKKGt";
            this.lblKKGt.Size = new System.Drawing.Size(38, 15);
            this.lblKKGt.TabIndex = 1;
            this.lblKKGt.Text = "label3";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 52);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(82, 15);
            this.label2.TabIndex = 0;
            this.label2.Text = "İndirimli Fiyat:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(5, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(82, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "Genel Toplam:";
            // 
            // gbHavaleEft
            // 
            this.gbHavaleEft.Controls.Add(this.lblHEKodu);
            this.gbHavaleEft.Controls.Add(this.label3);
            this.gbHavaleEft.Controls.Add(this.lblHEiTop);
            this.gbHavaleEft.Controls.Add(this.label11);
            this.gbHavaleEft.Controls.Add(this.lblHEGTop);
            this.gbHavaleEft.Controls.Add(this.label10);
            this.gbHavaleEft.Location = new System.Drawing.Point(23, 252);
            this.gbHavaleEft.Name = "gbHavaleEft";
            this.gbHavaleEft.Size = new System.Drawing.Size(324, 107);
            this.gbHavaleEft.TabIndex = 4;
            this.gbHavaleEft.TabStop = false;
            this.gbHavaleEft.Text = "HAVALE/EFT İLE ÖDEME";
            // 
            // lblHEKodu
            // 
            this.lblHEKodu.AutoSize = true;
            this.lblHEKodu.Location = new System.Drawing.Point(138, 70);
            this.lblHEKodu.Name = "lblHEKodu";
            this.lblHEKodu.Size = new System.Drawing.Size(38, 15);
            this.lblHEKodu.TabIndex = 7;
            this.lblHEKodu.Text = "label3";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(17, 70);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(106, 15);
            this.label3.TabIndex = 7;
            this.label3.Text = "HAVALE/EFT Kodu:";
            // 
            // lblHEiTop
            // 
            this.lblHEiTop.AutoSize = true;
            this.lblHEiTop.Location = new System.Drawing.Point(110, 46);
            this.lblHEiTop.Name = "lblHEiTop";
            this.lblHEiTop.Size = new System.Drawing.Size(38, 15);
            this.lblHEiTop.TabIndex = 1;
            this.lblHEiTop.Text = "label3";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(17, 19);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(82, 15);
            this.label11.TabIndex = 0;
            this.label11.Text = "Genel Toplam:";
            // 
            // lblHEGTop
            // 
            this.lblHEGTop.AutoSize = true;
            this.lblHEGTop.Location = new System.Drawing.Point(110, 22);
            this.lblHEGTop.Name = "lblHEGTop";
            this.lblHEGTop.Size = new System.Drawing.Size(38, 15);
            this.lblHEGTop.TabIndex = 1;
            this.lblHEGTop.Text = "label3";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(17, 46);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(82, 15);
            this.label10.TabIndex = 0;
            this.label10.Text = "İndirimli Fiyat:";
            // 
            // listBox1
            // 
            this.listBox1.BackColor = System.Drawing.SystemColors.Menu;
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 15;
            this.listBox1.Location = new System.Drawing.Point(6, 40);
            this.listBox1.Name = "listBox1";
            this.listBox1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.listBox1.Size = new System.Drawing.Size(125, 184);
            this.listBox1.TabIndex = 5;
            // 
            // listBox2
            // 
            this.listBox2.BackColor = System.Drawing.SystemColors.Menu;
            this.listBox2.FormattingEnabled = true;
            this.listBox2.ItemHeight = 15;
            this.listBox2.Location = new System.Drawing.Point(143, 40);
            this.listBox2.Name = "listBox2";
            this.listBox2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.listBox2.Size = new System.Drawing.Size(64, 184);
            this.listBox2.TabIndex = 5;
            // 
            // listBox3
            // 
            this.listBox3.BackColor = System.Drawing.SystemColors.Menu;
            this.listBox3.FormattingEnabled = true;
            this.listBox3.ItemHeight = 15;
            this.listBox3.Location = new System.Drawing.Point(213, 40);
            this.listBox3.Name = "listBox3";
            this.listBox3.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.listBox3.Size = new System.Drawing.Size(62, 184);
            this.listBox3.TabIndex = 5;
            // 
            // listBox4
            // 
            this.listBox4.BackColor = System.Drawing.SystemColors.Menu;
            this.listBox4.FormattingEnabled = true;
            this.listBox4.ItemHeight = 15;
            this.listBox4.Location = new System.Drawing.Point(281, 40);
            this.listBox4.Name = "listBox4";
            this.listBox4.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.listBox4.Size = new System.Drawing.Size(66, 184);
            this.listBox4.TabIndex = 5;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(669, 442);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(204, 23);
            this.button1.TabIndex = 6;
            this.button1.Text = "SİPARİŞİ TAMAMLA";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(40, 14);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(61, 15);
            this.label14.TabIndex = 7;
            this.label14.Text = "ÜRÜN ADI";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(161, 14);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(35, 15);
            this.label15.TabIndex = 7;
            this.label15.Text = "ADET";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(287, 14);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(53, 15);
            this.label16.TabIndex = 7;
            this.label16.Text = "TOPLAM";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(226, 14);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(35, 15);
            this.label17.TabIndex = 7;
            this.label17.Text = "SATIŞ";
            // 
            // odemeYap
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Teal;
            this.ClientSize = new System.Drawing.Size(885, 477);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.gbNakit);
            this.Controls.Add(this.gbHavaleEft);
            this.Controls.Add(this.listBox4);
            this.Controls.Add(this.listBox3);
            this.Controls.Add(this.listBox2);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.gbKredikart);
            this.Controls.Add(this.rdHavaleEft);
            this.Controls.Add(this.rdKredikart);
            this.Controls.Add(this.rdNakit);
            this.Name = "odemeYap";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Sipariş Ödeme Sayafası";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.odemeYap_FormClosing);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.odemeYap_FormClosed);
            this.Load += new System.EventHandler(this.odemeYap_Load);
            this.gbNakit.ResumeLayout(false);
            this.gbNakit.PerformLayout();
            this.gbKredikart.ResumeLayout(false);
            this.gbKredikart.PerformLayout();
            this.gbHavaleEft.ResumeLayout(false);
            this.gbHavaleEft.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private RadioButton rdNakit;
        private RadioButton rdKredikart;
        private RadioButton rdHavaleEft;
        private GroupBox gbNakit;
        private GroupBox gbKredikart;
        private GroupBox gbHavaleEft;
        private ListBox listBox1;
        private ListBox listBox2;
        private ListBox listBox3;
        private ListBox listBox4;
        private Label lblNiTop;
        private Label label5;
        private Label label6;
        private Label lblNGTop;
        private Label lblKKiTop;
        private Label lblKKGt;
        private Label label2;
        private Label label1;
        private Button button1;
        private Label lblHEiTop;
        private Label label11;
        private Label lblHEGTop;
        private Label label10;
        private Label lblHEKodu;
        private Label label3;
        private MaskedTextBox txtKartno;
        private TextBox txtAdsoyad;
        private Label label9;
        private Label label8;
        private Label label7;
        private Label label4;
        private MaskedTextBox txtCvv;
        private ComboBox comboBox6;
        private ComboBox comboBox4;
        private ComboBox txtYil;
        private ComboBox comboBox5;
        private ComboBox comboBox3;
        private ComboBox txtAy;
        private Label label13;
        private Label label12;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private Label label14;
        private Label label15;
        private Label label16;
        private Label label17;
    }
}